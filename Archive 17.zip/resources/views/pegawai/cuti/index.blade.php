<div class="row">
  <div class="col-12 col-sm-6 col-md-3">
    <div class="info-box">
      <span class="info-box-icon bg-info elevation-1"><i class="fas fa-calendar-check"></i></span>

      <div class="info-box-content">
        <span class="info-box-text">Kuota Cuti</span>
        <span class="info-box-number">
          <?php if($kuota_cuti) { echo $kuota_cuti->kuota; }else{ echo 0; } ?>
          <small>Hari</small>
        </span>
      </div>
      <!-- /.info-box-content -->
    </div>
    <!-- /.info-box -->
  </div>
</div>
