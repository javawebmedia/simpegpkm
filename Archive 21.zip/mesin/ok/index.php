<html>
<head><title>Contoh Koneksi Mesin Absensi Mengunakan SOAP Web Service</title></head>
<body bgcolor="#caffcb">

<H3>Contoh Koneksi Mesin Absensi Mengunakan SOAP Web Service</H3><BR>

<a href="tarik-data.php">Download Log Data</a><BR><BR>
<a href="clear-data.php">Clear Log Data</a><BR><BR>
<a href="upload-nama.php">Upload Nama</a><BR><BR><BR>

<a href="download-sidik-jari.php">Download Sidik Jari</a><BR><BR>
<a href="hapus-sidik-jari.php">Hapus Sidik Jari</a><BR><BR>
<a href="upload-sidik-jari.php">Upload Sidik Jari</a><BR><BR><BR>

<a href="syn-time.php">Syncronize Time</a><BR><BR>
<a href="hapus-user.php">Hapus User</a><BR><BR>

</body>
</html>

