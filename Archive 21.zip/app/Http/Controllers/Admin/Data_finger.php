<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Libraries\Parser;

class Data_finger extends Controller
{
    // index
    public function index()
    {
        // proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        $data = [   'title'     => 'Data Kehadiran Pegawai',
                    'content'   => 'admin/data_finger/index'
                ];
        return view('admin/layout/wrapper',$data);
    }

    // tarik
    public function tarik($id_mesin)
    {
        $IP         = "192.168.1.14";
        $Key        = "8050";
        $Connect = @fsockopen($IP, "80", $errno, $errstr, 1);
        if($Connect){
            $soap_request="<GetAttLog><ArgComKey xsi:type=\"xsd:integer\">".$Key."</ArgComKey><Arg><PIN xsi:type=\"xsd:integer\">All</PIN></Arg></GetAttLog>";
            $newLine="\r\n";
            fputs($Connect, "POST /iWsService HTTP/1.0".$newLine);
            fputs($Connect, "Content-Type: text/xml".$newLine);
            fputs($Connect, "Content-Length: ".strlen($soap_request).$newLine.$newLine);
            fputs($Connect, $soap_request.$newLine);
            $buffer="";
            while($Response=fgets($Connect, 1024)){
                $buffer=$buffer.$Response;
            }
        }else{
            echo "Koneksi Gagal";
        } 

        $buffer = Parser::parseData($buffer,"<GetAttLogResponse>","</GetAttLogResponse>");
        $buffer=explode("\r\n",$buffer);
        for($a=0;$a<count($buffer);$a++){
            $data=Parser::parseData($buffer[$a],"<Row>","</Row>");
            $PIN=Parser::parseData($data,"<PIN>","</PIN>");
            $DateTime=Parser::parseData($data,"<DateTime>","</DateTime>");
            $Verified=Parser::parseData($data,"<Verified>","</Verified>");
            $Status=Parser::parseData($data,"<Status>","</Status>");
            if($PIN =='') {}else{
                echo 'PIN: '.$PIN.'<br>';
                echo 'DateTime: '.$DateTime.'<br>';
                echo 'Verified: '.$Verified.'<br>';
                echo 'Status: '.$Status.'<br>';
                echo '<hr>';
            }
            
        }
        
    }

    // parser
    public function parser()
    {

    }
}
