<?php 
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Kuota_cuti_model;
use App\Models\Pegawai_model;

class Kuota_cuti extends Controller
{
	// main
	public function index()
	{
		// proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
		$m_kuota_cuti 	= new Kuota_cuti_model();
		$m_pegawai 		= new Pegawai_model();

		if(isset($_GET['tahun'])) {
			$tahun 	= $_GET['tahun'];
			$nip 	= $_GET['nip'];
		}else{
			$tahun 	= date('Y');
			$nip 	= 'Semua';
		}

		$list_tahun 	= $m_kuota_cuti->list_tahun();
		$kuota_cuti 	= $m_kuota_cuti->tahun($tahun);
		$pegawai 		= $m_pegawai->listing();
		$total 			= $m_kuota_cuti->total();

		// print_r($kuota_cuti);

		$data = [   'title'     		=> 'Kuota Cuti Pegawai',
					'kuota_cuti'		=> $kuota_cuti,
					'pegawai'			=> $pegawai,
					'pegawai2'			=> $pegawai,
					'list_tahun'		=> $list_tahun,
					'content'			=> 'admin/kuota_cuti/index'
                ];
        return view('admin/layout/wrapper',$data);
	}

	// proses_tambah
	public function proses_tambah(Request $request)
	{
		
		// proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        request()->validate([
                            'nip' => 'required'
                            ]);
        $data = [	'id_user'			=> Session()->get('id_pegawai'),
					'nip'				=> $request->nip,
					'tahun'				=> $request->tahun,
					'kuota'				=> $request->kuota,
					'keterangan'		=> $request->keterangan,
					'tanggal_post'		=> date('Y-m-d H:i:s')
				];
		// check
		$m_kuota_cuti 	= new Kuota_cuti_model();
		$check 			= $m_kuota_cuti->tahun_nip($request->tahun,$request->nip);
		if($check > 0) {
			DB::table('kuota_cuti')->where(['nip' 	=> $request->nip,
											'tahun'	=> $request->tahun])->update($data);
		}else{
			DB::table('kuota_cuti')->insert($data);
		}
		// end check
        return redirect('admin/kuota-cuti')->with(['sukses' => 'Data telah ditambah']);
	}

	// edit
	public function edit($id_kuota_cuti)
	{
		$m_kuota_cuti 	= new Kuota_cuti_model();
		$m_pegawai 		= new Pegawai_model();
		$kuota_cuti 	= $m_kuota_cuti->detail($id_kuota_cuti);
		$pegawai 		= $m_pegawai->nip($kuota_cuti->nip);

		$data = [	'title'		=> 'Edit Kuota Cuti: '.$pegawai->nama_lengkap.' - Periode: '.$kuota_cuti->tahun,
					'kuota_cuti'=> $kuota_cuti,
					'pegawai'	=> $pegawai,
					'content'	=> 'admin/kuota_cuti/edit'
				];
		echo view('admin/layout/wrapper',$data);
	}

	// proses_edit
	public function proses_edit(Request $request)
	{
		
		// proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        request()->validate([
                            'nip' => 'required'
                            ]);
        $data = [	'id_kuota_cuti'		=> $request->id_kuota_cuti,
        			'id_user'			=> Session()->get('id_pegawai'),
					'nip'				=> $request->nip,
					'tahun'				=> $request->tahun,
					'kuota'				=> $request->kuota,
					'keterangan'		=> $request->keterangan,
				];
        DB::table('kuota_cuti')->where('id_kuota_cuti',$request->id_kuota_cuti)->update($data);
        return redirect('admin/kuota_cuti')->with(['sukses' => 'Data telah ditambah']);
	}

	// delete
	public function delete($id_kuota_cuti)
	{
		// proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        DB::table('kuota_cuti')->where('id_kuota_cuti',$id_kuota_cuti)->delete();
        return redirect('admin/kuota_cuti')->with(['sukses' => 'Data telah dihapus']);
	}
}