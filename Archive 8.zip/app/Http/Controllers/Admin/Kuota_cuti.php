<?php 
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Kuota_cuti_model;
use App\Models\Pegawai_model;

class Kuota_cuti extends Controller
{
	// main
	public function index()
	{
		// proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
		$m_kuota_cuti 	= new Kuota_cuti_model();
		$m_pegawai 		= new Pegawai_model();

		if(isset($_GET['tahun'])) {
			$tahun 	= $_GET['tahun'];
			$nip 	= $_GET['nip'];
		}else{
			$tahun 	= date('Y');
			$nip 	= 'Semua';
		}

		$list_tahun 	= $m_kuota_cuti->list_tahun();
		$kuota_cuti 	= $m_kuota_cuti->tahun($tahun);
		$pegawai 		= $m_pegawai->listing();
		$total 			= $m_kuota_cuti->total();

		// print_r($kuota_cuti);

		$data = [   'title'     		=> 'Kuota Cuti Pegawai',
					'kuota_cuti'		=> $kuota_cuti,
					'pegawai'			=> $pegawai,
					'pegawai2'			=> $pegawai,
					'list_tahun'		=> $list_tahun,
					'content'			=> 'admin/kuota_cuti/index'
                ];
        return view('admin/layout/wrapper',$data);
	}

	// proses_tambah
	public function proses_tambah(Request $request)
	{
		
		// proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        request()->validate([
                            'nip' => 'required'
                            ]);
        $data = [	'id_user'			=> Session()->get('id_pegawai'),
					'nip'				=> $request->nip,
					'tahun'				=> $request->tahun,
					'kuota'				=> $request->kuota,
					'keterangan'		=> $request->keterangan,
					'tanggal_post'		=> date('Y-m-d H:i:s')
				];
        DB::table('kuota_cuti')->insert($data);
        return redirect('admin/kuota-cuti')->with(['sukses' => 'Data telah ditambah']);
	}

	// weekend
	public function weekend()
	{
		$m_kuota_cuti 		= new Kuota_cuti_model();
		$m_pegawai 	= new Pegawai_model();
		$kuota_cuti 			= $m_kuota_cuti->listing();
		$pegawai 	= $m_pegawai->listing();
		$total 			= $m_kuota_cuti->total();

		
		$data = [   'title'     		=> 'Setting Weekend Sebagai Hari Kuota_cuti',
					'kuota_cuti'				=> $kuota_cuti,
					'pegawai'		=> $pegawai,
					'content'			=> 'admin/kuota_cuti/weekend'
                ];
        return view('admin/layout/wrapper',$data);
	}

	// proses_weekend
	public function proses_weekend(Request $request)
	{
		// Start validasi
		request()->validate([
                            'id_pegawai' => 'required'
                            ]);
		// masuk database
		$year = $request->tahun;
		// Start and end dates of the year
		$startDate = new \DateTime("$year-01-01");
		$endDate = new \DateTime("$year-12-31");

		// Initialize an array to store the dates
		$saturdays = [];
		$sundays = [];

		// Loop through the dates and check the day of the week
		$currentDate = clone $startDate;
		while ($currentDate <= $endDate) {
		    if ($currentDate->format('N') == 6) { // Saturday (N=6)
		        $saturdays[] = $currentDate->format('Y-m-d');
		    } elseif ($currentDate->format('N') == 7) { // Sunday (N=7)
		        $sundays[] = $currentDate->format('Y-m-d');
		    }
		    $currentDate->modify('+1 day'); // Move to the next day
		}
		foreach($saturdays as $sabtu) {
			$data = [	'id_pegawai'		=> Session()->get('id_pegawai'),
						'id_pegawai'	=> $request->id_pegawai,
						'tanggal_kuota_cuti'		=> $sabtu,
						'tahun'				=> $request->tahun,
						'status_kuota_cuti'		=> $request->status_kuota_cuti,
						'keterangan'		=> $request->keterangan,
						'tanggal_update'	=> date('Y-m-d H:i:s')
					];
			DB::table('kuota_cuti')->insert($data);
		}
		foreach($sundays as $minggu) {
			$data = [	'id_pegawai'		=> Session()->get('id_pegawai'),
						'id_pegawai'	=> $request->id_pegawai,
						'tanggal_kuota_cuti'		=> $minggu,
						'tahun'				=> $request->tahun,
						'status_kuota_cuti'		=> $request->status_kuota_cuti,
						'keterangan'		=> $request->keterangan,
						'tanggal_update'	=> date('Y-m-d H:i:s')
					];
			DB::table('kuota_cuti')->insert($data);
		}
		// masuk database
		
        return redirect('admin/kuota_cuti')->with(['sukses' => 'Data telah ditambah']);
	}

	// tahunan
	public function tahunan()
	{
		$year = $_GET['q'];
		// Start and end dates of the year
		$startDate = new \DateTime("$year-01-01");
		$endDate = new \DateTime("$year-12-31");

		// Initialize an array to store the dates
		$saturdays = [];
		$sundays = [];

		// Loop through the dates and check the day of the week
		$currentDate = clone $startDate;
		while ($currentDate <= $endDate) {
		    if ($currentDate->format('N') == 6) { // Saturday (N=6)
		        $saturdays[] = $currentDate->format('Y-m-d');
		    } elseif ($currentDate->format('N') == 7) { // Sunday (N=7)
		        $sundays[] = $currentDate->format('Y-m-d');
		    }
		    $currentDate->modify('+1 day'); // Move to the next day
		}

		// Print the dates
		echo '<div class="alert alert-light mt-1"><strong>Hari Sabtu ('.count($saturdays).' Hari):</strong><br>';
		foreach($saturdays as $sabtu) {
			echo '<span class="badge badge-success mr-1">'.date('d M Y',strtotime($sabtu)).'</span>';
		}
		echo '</div>';
		echo '<div class="alert alert-light mt-1"><strong>Hari Minggu ('.count($sundays).' Hari):</strong><br>';
		foreach($sundays as $minggu) {
			echo '<span class="badge badge-success mr-1">'.date('d M Y',strtotime($minggu)).'</span>';
		}
		echo '</div>';
	}

	// urutkan
	public function urutkan()
	{
		$m_kuota_cuti = new Kuota_cuti_model();
		$kuota_cuti 	= $m_kuota_cuti->listing();

		if(isset($_POST['page_id_array'])) 
		{
			for($i=0; $i<count($_POST["page_id_array"]); $i++)
			{
				$data = [	'id_kuota_cuti'	=> $_POST["page_id_array"][$i],
							'urutan'				=> $i
						];
			 	$m_kuota_cuti->edit($data);
			}
			$this->session->setFlashdata('sukses','Data telah diurutkan');
		}

		$data = [   'title'     	=> 'Urutkan Hari dan Tanggal Kuota_cuti',
					'kuota_cuti'	=> $kuota_cuti,
					'content'		=> 'admin/kuota_cuti/urutkan'
                ];
        return view('admin/layout/wrapper',$data);
    }

	// edit
	public function edit($id_kuota_cuti)
	{
		$m_kuota_cuti 	= new Kuota_cuti_model();
		$kuota_cuti 		= $m_kuota_cuti->detail($id_kuota_cuti);
		$data = [	'title'		=> 'Edit Hari dan Tanggal Kuota_cuti: '.date('Y-m-d',strtotime($kuota_cuti->tanggal_kuota_cuti)),
					'kuota_cuti'		=> $kuota_cuti,
					'content'	=> 'admin/kuota_cuti/edit'
				];
		echo view('admin/layout/wrapper',$data);
	}

	// proses_edit
	public function proses_edit(Request $request)
	{
		
		// proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        request()->validate([
                            'tanggal_kuota_cuti' => 'required|unique:kuota_cuti'
                            ]);
        $data = [	'id_kuota_cuti'			=> $request->id_kuota_cuti,
        			'id_pegawai'		=> Session()->get('id_pegawai'),
					'id_pegawai'	=> $request->id_pegawai,
					'tanggal_kuota_cuti'		=> date('Y-m-d',strtotime($request->tanggal_kuota_cuti)),
					'tahun'				=> date('Y',strtotime($request->tanggal_kuota_cuti)),
					'status_kuota_cuti'		=> $request->status_kuota_cuti,
					'keterangan'		=> $request->keterangan,
				];
        DB::table('kuota_cuti')->where('id_kuota_cuti',$request->id_kuota_cuti)->update($data);
        return redirect('admin/kuota_cuti')->with(['sukses' => 'Data telah ditambah']);
	}

	// delete
	public function delete($id_kuota_cuti)
	{
		// proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        DB::table('kuota_cuti')->where('id_kuota_cuti',$id_kuota_cuti)->delete();
        return redirect('admin/kuota_cuti')->with(['sukses' => 'Data telah dihapus']);
	}
}