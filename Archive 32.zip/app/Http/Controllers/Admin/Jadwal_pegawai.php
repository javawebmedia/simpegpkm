<?php
namespace App\Http\Controllers\Admin;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Libraries\Parser;
use App\Models\Pegawai_model;
use App\Models\Jadwal_pegawai_model;

class Jadwal_pegawai extends Controller
{
    // index
    public function index()
    {
        // proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        $m_jadwal_pegawai   = new Jadwal_pegawai_model();
        $m_pegawai          = new Pegawai_model();
        $pegawai            = $m_pegawai->listing();

        if(isset($_GET['thbl'])) {
            $thbl   = $_GET['thbl'];
            $tahun  = $_GET['tahun'];
            $bulan  = $_GET['bulan'];
        }else{
            $thbl   = date('Ym');
            $tahun  = date('Y');
            $bulan  = date('m');
        }

        $data = [   'title'             => 'Data Jam Kerja Pegawai',
                    'm_jadwal_pegawai'  => $m_jadwal_pegawai,
                    'pegawai'           => $pegawai,
                    'thbl'              => $thbl,
                    'tahun'             => $tahun,
                    'bulan'             => $bulan,
                    'content'           => 'admin/jadwal_pegawai/index'
                ];
        return view('admin/layout/wrapper',$data);
    }

    // tarik
    public function tarik($id_pegawai)
    {
        $m_pegawai          = new Pegawai_model();
        $m_jadwal_pegawai          = new Jadwal_pegawai_model();
        $pegawai            = $m_pegawai->detail($id_pegawai);
        $ip_pegawai         = $pegawai->ip_pegawai;
        $key_pegawai        = $pegawai->key_pegawai;

        $Connect        = @fsockopen($ip_pegawai, "80", $errno, $errstr, 1);
        if($Connect){
            $soap_request="<GetAttLog><ArgComKey xsi:type=\"xsd:integer\">".$key_pegawai."</ArgComKey><Arg><PIN xsi:type=\"xsd:integer\">All</PIN></Arg></GetAttLog>";
            $newLine="\r\n";
            fputs($Connect, "POST /iWsService HTTP/1.0".$newLine);
            fputs($Connect, "Content-Type: text/xml".$newLine);
            fputs($Connect, "Content-Length: ".strlen($soap_request).$newLine.$newLine);
            fputs($Connect, $soap_request.$newLine);
            $buffer="";
            while($Response=fgets($Connect, 1024)){
                $buffer=$buffer.$Response;
            }
        }else{
            echo "Koneksi Gagal";
        } 

        $buffer = Parser::parseData($buffer,"<GetAttLogResponse>","</GetAttLogResponse>");
        $buffer=explode("\r\n",$buffer);
        for($a=0;$a<count($buffer);$a++){
            $data       = Parser::parseData($buffer[$a],"<Row>","</Row>");
            $PIN        = Parser::parseData($data,"<PIN>","</PIN>");
            $DateTime   = Parser::parseData($data,"<DateTime>","</DateTime>");
            $Verified   = Parser::parseData($data,"<Verified>","</Verified>");
            $Status     = Parser::parseData($data,"<Status>","</Status>");
            $WorkCode   = Parser::parseData($data,"<WorkCode>","</WorkCode>");
            if($PIN =='') {}else{
                // echo 'PIN: '.$PIN.'<br>';
                // echo 'DateTime: '.$DateTime.'<br>';
                // echo 'Verified: '.$Verified.'<br>';
                // echo 'Status: '.$Status.'<br>';
                // echo '<hr>';
                $check = $m_jadwal_pegawai->check($id_pegawai,$PIN,$DateTime);
                if(count($check) > 0) {
                }else{
                    $data = [   'id_pegawai'        => $id_pegawai,
                                'ip_pegawai'        => $ip_pegawai,
                                'pin'                   => $PIN,
                                'tanggal_finger'        => date('Y-m-d',strtotime($DateTime)),
                                'waktu_finger'          => $DateTime,
                                'verified'              => $Verified,
                                'status_jadwal_pegawai'    => $Status,
                                'work_code'             => $WorkCode
                            ];
                    DB::table('jadwal_pegawai')->insert($data);
                }
            }
        }
        return redirect('admin/data-finger')->with(['sukses' => 'Data absensi biometrik telah ditambah']);
    }

    // parser
    public function parser()
    {

    }
}
