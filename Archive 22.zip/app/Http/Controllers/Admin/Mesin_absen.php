<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Mesin_absen extends Controller
{
    // halaman mesin_absen
    public function index()
    {
        // proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        // ambil data mesin_absen
        $mesin_absen = DB::table('mesin_absen')->get();

        $data = [   'title'         => 'Data Master Jenis Cuti',
                    'mesin_absen'   => $mesin_absen,
                    'content'       => 'admin/mesin_absen/index'
                ];
        return view('admin/layout/wrapper',$data);
    }

    // edit
    public function edit($id_mesin_absen)
    {
        // proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        // ambil data mesin_absen
        $mesin_absen = DB::table('mesin_absen')->where('id_mesin_absen',$id_mesin_absen)->first();

        $data = [   'title'         => 'Edit Jenis Cuti: '.$mesin_absen->nama_mesin_absen,
                    'mesin_absen'   => $mesin_absen,
                    'content'       => 'admin/mesin_absen/edit'
                ];
        return view('admin/layout/wrapper',$data);
    }

    // proses tambah data
    public function tambah(Request $request)
    {
        // proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        request()->validate([
                            'nama_mesin_absen' => 'required|unique:mesin_absen',
                            'urutan'     => 'required',
                            ]);

        DB::table('mesin_absen')->insert([
            'id_pegawai'        => Session()->get('id_pegawai'),
            'nama_mesin_absen'  => $request->nama_mesin_absen,
            'keterangan'        => $request->keterangan,
            'urutan'            => $request->urutan
        ]);
        return redirect('admin/mesin-absen')->with(['sukses' => 'Data telah ditambah']);
    }

    // proses edit data
    public function proses_edit(Request $request)
    {
        // proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        request()->validate([
                            'nama_mesin_absen' => 'required',
                            'urutan'     => 'required',
                            ]);

        DB::table('mesin_absen')->where('id_mesin_absen',$request->id_mesin_absen)->update([
            'id_pegawai'        => Session()->get('id_pegawai'),
            'nama_mesin_absen'  => $request->nama_mesin_absen,
            'keterangan'        => $request->keterangan,
            'urutan'            => $request->urutan
        ]);
        return redirect('admin/mesin-absen')->with(['sukses' => 'Data telah diedit']);
    }

    // delete
    public function delete($id_mesin_absen)
    {
        // proteksi halaman
        if(Session()->get('username')=="") { 
            $last_page = url()->full();
            return redirect('login?redirect='.$last_page)->with(['warning' => 'Mohon maaf, Anda belum login']);
        }
        // end proteksi halaman
        DB::table('mesin_absen')->where('id_mesin_absen',$id_mesin_absen)->delete();
        return redirect('admin/mesin-absen')->with(['sukses' => 'Data telah dihapus']);
    }
}
