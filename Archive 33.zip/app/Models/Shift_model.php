<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Shift_model extends Model
{
    // listing semua
    public function listing()
    {
        $query = DB::table('shift')
            ->select('*')
            ->orderBy('shift.id_shift','DESC')
            ->get();
        return $query;
    }

    // detail
    public function detail($id_shift)
    {
        $query = DB::table('shift')
            ->select('*')
            ->where('shift.id_shift',$id_shift)
            ->orderBy('shift.id_shift','DESC')
            ->first();
        return $query;
    }
}
