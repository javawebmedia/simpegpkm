<table class="table table-sm tabelku">
	<thead>
		<tr>
			<th></th>
			<th>PEGAWAI</th>
			<th>TANGGAL</th>
			<th>JAM</th>
			<th>Mesin Absen</th>
			<th></th>
		</tr>
	</thead>
	<tbody>
		<?php $no=1; foreach($data_finger as $data_finger) { ?>
		<tr>
			<td></td>
			<td><?php echo $data_finger->nama_lengkap ?></td>
			<td><?php echo date('d-m-Y',strtotime($data_finger->waktu_finger)) ?></td>
			<td><?php echo date('H:i:s',strtotime($data_finger->waktu_finger)) ?></td>
			<td><?php echo $data_finger->ip_mesin_absen ?></td>
			<td></td>
		</tr>
		<?php $no++; } ?>
	</tbody>
</table>